# TP2 - Aula 05 - Factory Method e Simple Factory

## FATEC - Desenvolvimento de Software Multiplataforma

Atividade prática da Aula 5 sobre padrões criacionais.

## Objetivo

O projeto demonstra como encapsular a criação de objetos utilizando:

- Simple Factory
- Factory Method
- Princípio Aberto/Fechado (OCP)
- Redução do acoplamento entre cliente e classes concretas

O contexto utilizado é o SIGA, no qual cada perfil de usuário possui um painel inicial diferente.

## Perfis

O projeto possui quatro perfis:

- Aluno
- Professor
- Coordenador
- Administrador

O perfil Administrador foi utilizado para demonstrar a inclusão de um novo perfil.

## Etapa 1 - Identificação do problema

No código original, a criação dos painéis era feita diretamente com `new` dentro de uma estrutura `if/else`.

Isso gera acoplamento entre o código cliente e as classes concretas.

Além disso, para adicionar um novo perfil seria necessário modificar o código existente, dificultando a manutenção e contrariando o princípio Aberto/Fechado.

## Etapa 2 - Simple Factory

A classe `FabricaPainel` centraliza a criação dos objetos `Painel`.

O cliente solicita um painel para a fábrica e não precisa criar diretamente os objetos concretos.

Exemplo:

```java
FabricaPainel fabrica = new FabricaPainel();
Painel painel = fabrica.criarPainel("ALUNO");
painel.exibir();
```

## Etapa 3 - Factory Method

Na segunda solução foi criada a classe abstrata `CriadorPainel`.

O método `criarPainel()` é sobrescrito pelos criadores concretos:

- `CriadorPainelAluno`
- `CriadorPainelProfessor`
- `CriadorPainelCoordenador`
- `CriadorPainelAdministrador`

Cada criador é responsável pela criação de seu respectivo produto.

## Etapa 4 - Novo perfil

Foi acrescentado o perfil `Administrador`.

Foram criadas:

- `PainelAdministrador`
- `CriadorPainelAdministrador`

Os criadores anteriores não precisaram ser alterados.

Isso demonstra a ideia do princípio Aberto/Fechado: o sistema pode ser estendido com novos comportamentos sem precisar modificar as classes existentes.

## Etapa 5 - Diagrama UML

O diagrama da solução final está disponível na pasta `uml`.

Arquivo:

`uml/diagrama-final.puml`

O diagrama pode ser aberto em ferramentas compatíveis com PlantUML.

## Estrutura do projeto

```text
TP2_Aula05_Factory/
│
├── README.md
│
├── src/
│   ├── Painel.java
│   ├── PainelAluno.java
│   ├── PainelProfessor.java
│   ├── PainelCoordenador.java
│   ├── PainelAdministrador.java
│   ├── FabricaPainel.java
│   ├── CriadorPainel.java
│   ├── CriadorPainelAluno.java
│   ├── CriadorPainelProfessor.java
│   ├── CriadorPainelCoordenador.java
│   ├── CriadorPainelAdministrador.java
│   └── Main.java
│
└── uml/
    └── diagrama-final.puml
```

## Como executar

É necessário utilizar Java JDK 17 ou superior.

No terminal, dentro da pasta do projeto:

```bash
javac -d out src/*.java
```

Depois:

```bash
java -cp out Main
```

## Saída esperada

```text
===== ETAPA 2 - SIMPLE FACTORY =====
Painel do aluno
Opções: consultar notas, frequência e disciplinas.

Painel do professor
Opções: lançar notas, frequência e consultar turmas.

Painel do coordenador
Opções: acompanhar cursos, turmas e professores.

===== ETAPA 3 - FACTORY METHOD =====
Painel do aluno
Opções: consultar notas, frequência e disciplinas.

Painel do professor
Opções: lançar notas, frequência e consultar turmas.

Painel do coordenador
Opções: acompanhar cursos, turmas e professores.

===== ETAPA 4 - NOVO PERFIL =====
Painel do administrador
Opções: gerenciar usuários e configurações do sistema.

Todos os painéis foram criados e exibidos com sucesso.
```

## Tecnologias

- Java
- JDK 17 ou superior
- Padrão Simple Factory
- Padrão Factory Method
- UML / PlantUML
