public class CriadorPainelAdministrador extends CriadorPainel {

    @Override
    public Painel criarPainel() {
        return new PainelAdministrador();
    }
}
