public class PainelAluno implements Painel {

    @Override
    public void exibir() {
        System.out.println("Painel do aluno");
        System.out.println("Opções: consultar notas, frequência e disciplinas.");
    }
}
