public class PainelProfessor implements Painel {

    @Override
    public void exibir() {
        System.out.println("Painel do professor");
        System.out.println("Opções: lançar notas, frequência e consultar turmas.");
    }
}
