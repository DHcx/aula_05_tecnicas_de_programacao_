public class PainelAdministrador implements Painel {

    @Override
    public void exibir() {
        System.out.println("Painel do administrador");
        System.out.println("Opções: gerenciar usuários e configurações do sistema.");
    }
}
